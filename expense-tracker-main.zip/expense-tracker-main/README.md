An application built on react to track (using CRUD) and visualize our daily expenses with the help of Pie Chart and Bar graph.

LIVE URL: https://expense-tracker-mauve-beta.vercel.app/

Desktop View
![image](https://github.com/Suyash00/expense-tracker/assets/82312866/27f0c2bf-2b46-4ef1-a8d4-903cda324426)

Mobile View
![image](https://github.com/Suyash00/expense-tracker/assets/82312866/647b8a4e-dd14-4d19-90f9-4c93d0cb6e00)
![image](https://github.com/Suyash00/expense-tracker/assets/82312866/7d70b25b-d51a-4eed-b3a5-c02fc13e29e4)

